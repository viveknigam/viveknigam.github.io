README for iop.jar

This jar file conatins alll the classes necessary for
the IOP application, jlambda interpeter, as well as
some third party classes and libraries. Most notable
is the BrowserLauncher2 classes. Please see the
contents of the included BrowserLauncherInfo for
more information about the BrowserLauncher2 libaray.



