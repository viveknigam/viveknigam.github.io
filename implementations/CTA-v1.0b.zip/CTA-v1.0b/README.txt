This is a prototype of a Clinical Trial Assistant (CTA) beta version developed 
by Vivek Nigam and Carolyn Talcott. 

=== Prerequisites

It contains a version af Maude and a version of IOP. To run it you 
will need a recent Java (e.g. 1.6) and Graphviz (i.e. dot), information 
about the latter can be found here: www.graphviz.org. On linux you
will need openjdk's Java, unless you have gnome installed, in which case
you can pick either openjdk or Oracle's java.

This version has been tested on an Ubuntu 13.04 machine.

=== How to Run CTA

Step 1. Download the appropriate zip file, and unzip it. It will unzip to a directory.
There are 4 folders in the zip file, IOP, MAUDE, Lib and Trials.

Step 2. In folder Trials, there are two trials available: LZZT and NSF. The LZZT folder
contains the specification of the 

"Xanomeline (LY246708) Safety and Efficacy of the Xanomeline Transdermal Therapeutic System 
(TTS) in Patients with Mild to Moderate Alzheimer's Disease"

using data provided in the CDISC SDM-XML specification package. 

The second trial SDM is a toy example of a trial with a number of simple activities.

Each folder one of these folders, LZZT and NSF, contains a folder Subjects with the log
information of a number of subjects as a Maude theory.

Step 3: Enter in either the LZZT or NSF folder and execute the following command in the console, 
assuming that the maude directory is in your path:

./../../IOP/iopbin/iop load-events.maude

A window should open with a list of subjects with two buttons "initSubject" and "initSubjectPlan". 
The former does not construct a graphical representation of the pre-order of activities, while
the latter does. This is the main difference between them.

=== Bug reports 

Please send bug reports to vivek.nigam@gmail.com.